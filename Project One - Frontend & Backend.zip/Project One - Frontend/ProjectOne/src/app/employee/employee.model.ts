export class Employee{
    id: number = 0;
    userName: string = '';
    password: string = '';
    address: string = '';
    jobType: number = 0;

}