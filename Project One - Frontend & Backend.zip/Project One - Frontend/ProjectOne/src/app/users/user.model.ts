export class User{
    userId: number = 0;
    userPassword: string = '';
    userName: string = '';
    userAddress: string = '';
    userType: string = '';

}