export class Reimburstment{
    id: number = 0;
    status: string = '';
    amount: number = 0.00;
    date: string = '';
    sumbitDate: string = '';
    employeeId: number = 0;
}